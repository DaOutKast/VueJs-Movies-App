<template>
    <div id="app">
        <MovieList></MovieList>
    </div>
</template>

<script>
import MoviesList from './components/MoiveList'

export default {
  name: 'app',
  components: {
    MoviesList
  }
}
</script>

<style>

</style>
