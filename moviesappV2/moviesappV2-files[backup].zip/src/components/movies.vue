<template>
    <div class="movies" id="app">
        <h1>{{ title }}</h1>

        <hr>

        <!--<div class="filter">-->
            <!--<input type="text" id="filter">-->
            <!--<label for="filter">filter</label>-->
        <!--</div>-->

        <div v-for="movie in movies" class="movie--item">
            <div class="">
                <img :src="movie.field_movie_poster[0].url" :alt="movie.field_movie_poster[0].alt">
            </div>

            <div class="">
                <h4>{{ movie.title[0].value }}</h4>
                <p>
                    <strong>Director:</strong> {{ movie.field_director[0].value }}
                </p>

                <div class="row">
                    <div class="">
                        <strong>Actors:</strong><br>
                        <span v-for="actor in movie.field_actors">
                    {{ actor.value }}<br>
                </span>
                    </div>

                    <div class="">
                        <strong>Genre:</strong><br>
                        <span v-for="genre in movie.field_genre">
                    {{ genre.value }}<br>
                </span>
                    </div>
                </div>

            </div>

        </div>

    </div>

</template>
<script>

    import axios from 'axios';

    export default {
        name: 'movies',
        data: function() {
            return {
                title: 'Welcome to the Movie List',
                movies: []
            }
        },

        mounted: function() {
            var _this = this
            axios.get('http://movies-api.dev.com/api/movies').then(function(ready) {
                _this.movies = ready.data
            })
        }
    }
</script>
<style scoped>
    h1, h2 {
        font-weight: normal;
    }

    ul {
        list-style-type: none;
        padding: 0;
    }

    li {
        display: inline-block;
        margin: 0 10px;
    }

    a {
        color: #42b983;
    }
</style>
