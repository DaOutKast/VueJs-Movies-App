import Vue from 'vue'
import Router from 'vue-router'
// import Hello from '@/components/Hello'
import movies from '@/components/movies'

Vue.use(Router)

export default new Router({
    routes: [
        // {
        //     path: '/',
        //     name: 'Hello',
        //     component: Hello
        // },
        {
            path: '/movies-list',
            name: 'Movie List',
            component: movies
        }
    ]
})
